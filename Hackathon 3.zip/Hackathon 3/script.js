<script>
document.addEventListener('DOMContentLoaded', function () {
    // Hero section button interactions
    document.querySelector('.hero button:first-of-type').addEventListener('click', function () {
        window.location.href = '#services';
    });
    
    document.querySelector('.hero button:last-of-type').addEventListener('click', function () {
        window.location.href = '#about';
    });

    // Carousel functionality for testimonials
    const carousel = document.querySelector('.testimonials .carousel');
    let isDown = false;
    let startX;
    let scrollLeft;

    carousel.addEventListener('mousedown', (e) => {
        isDown = true;
        carousel.classList.add('active');
        startX = e.pageX - carousel.offsetLeft;
        scrollLeft = carousel.scrollLeft;
    });

    carousel.addEventListener('mouseleave', () => {
        isDown = false;
        carousel.classList.remove('active');
    });

    carousel.addEventListener('mouseup', () => {
        isDown = false;
        carousel.classList.remove('active');
    });

    carousel.addEventListener('mousemove', (e) => {
        if (!isDown) return;
        e.preventDefault();
        const x = e.pageX - carousel.offsetLeft;
        const walk = (x - startX) * 2; //scroll-fast
        carousel.scrollLeft = scrollLeft - walk;
    });
});
</script>
